package com.example.expensetracker
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.expensetracker.ui.theme.ExpenseTrackerTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Expense(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val category: String,
    val amount: Double,
    val date: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ExpenseTrackerTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    SmartExpenseTracker(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SmartExpenseTracker(modifier: Modifier = Modifier) {
    val monthlyBudget = 500.0

    val expenses = remember {
        mutableStateListOf(
            Expense(title = "Burger", category = "Food", amount = 12.50, date = "Today"),
            Expense(title = "Uber", category = "Transport", amount = 18.00, date = "Today"),
            Expense(title = "Internet Bill", category = "Bills", amount = 60.00, date = "Yesterday"),
            Expense(title = "Coffee", category = "Food", amount = 4.25, date = "Yesterday"),
            Expense(title = "Movie Ticket", category = "Entertainment", amount = 14.00, date = "Oct 15"),
            Expense(title = "Groceries", category = "Food", amount = 42.80, date = "Oct 14"),
            Expense(title = "Taxi", category = "Transport", amount = 9.50, date = "Oct 14")
        )
    }

    var showAddDialog by remember { mutableStateOf(false) }

    val totalSpent = expenses.sumOf { it.amount }
    val remainingBudget = monthlyBudget - totalSpent
    val progress = (totalSpent / monthlyBudget).coerceIn(0.0, 1.0).toFloat()
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        label = "budgetProgress"
    )

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFFF3F4F6)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                HeaderSection()
            }

            item {
                BudgetCard(
                    totalSpent = totalSpent,
                    monthlyBudget = monthlyBudget,
                    remainingBudget = remainingBudget,
                    progress = animatedProgress,
                    onAddClick = {
                        showAddDialog = true
                    }
                )
            }

            item {
                QuickStatsRow(expenses = expenses)
            }

            item {
                AnimatedVisibility(visible = remainingBudget < 100) {
                    WarningCard(remainingBudget = remainingBudget)
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Expenses",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111827),
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = "${expenses.size} items",
                        color = Color(0xFF6B7280),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            items(
                items = expenses
            ) { expense ->
                ExpenseItem(
                    expense = expense,
                    onDelete = {
                        expenses.remove(expense)
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showAddDialog) {
        AddExpenseDialog(
            onDismiss = {
                showAddDialog = false
            },
            onAddExpense = { title, amount, category ->
                expenses.add(
                    0,
                    Expense(
                        title = title,
                        amount = amount,
                        category = category,
                        date = currentDateText()
                    )
                )
                showAddDialog = false
            }
        )
    }
}

@Composable
fun HeaderSection() {
    Column {
        Text(
            text = "Smart Expense",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF111827)
        )

        Text(
            text = "Track smarter. Spend better.",
            style = MaterialTheme.typography.bodyLarge,
            color = Color(0xFF6B7280)
        )
    }
}

@Composable
fun BudgetCard(
    totalSpent: Double,
    monthlyBudget: Double,
    remainingBudget: Double,
    progress: Float,
    onAddClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF2563EB),
                            Color(0xFF7C3AED)
                        )
                    )
                )
                .padding(22.dp)
        ) {
            Column {
                Text(
                    text = "Monthly Spending",
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.bodyLarge
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "$${String.format("%.2f", totalSpent)}",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Budget: $${String.format("%.2f", monthlyBudget)}",
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.bodyMedium
                )

                Spacer(modifier = Modifier.height(16.dp))

                LinearProgressIndicator(
                    progress = progress,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(50.dp)),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.25f)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (remainingBudget >= 0) {
                        "$${String.format("%.2f", remainingBudget)} remaining"
                    } else {
                        "$${String.format("%.2f", kotlin.math.abs(remainingBudget))} over budget"
                    },
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onAddClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFF2563EB)
                    ),
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Text(
                        text = "+ Add Expense",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun QuickStatsRow(expenses: List<Expense>) {
    val foodTotal = expenses.filter { it.category == "Food" }.sumOf { it.amount }
    val transportTotal = expenses.filter { it.category == "Transport" }.sumOf { it.amount }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        MiniStatCard(
            title = "Food",
            amount = foodTotal,
            color = Color(0xFFF97316),
            modifier = Modifier.weight(1f)
        )

        MiniStatCard(
            title = "Transport",
            amount = transportTotal,
            color = Color(0xFF10B981),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun MiniStatCard(
    title: String,
    amount: Double,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        color = color.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = title.first().toString(),
                    color = color,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                color = Color(0xFF6B7280),
                style = MaterialTheme.typography.bodyMedium
            )

            Text(
                text = "$${String.format("%.2f", amount)}",
                color = Color(0xFF111827),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun WarningCard(remainingBudget: Double) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFFFBEB)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "!",
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier
                    .size(32.dp)
                    .background(
                        color = Color(0xFFD97706),
                        shape = RoundedCornerShape(50.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = if (remainingBudget >= 0) {
                    "Careful — your remaining budget is getting low."
                } else {
                    "You are over your monthly budget."
                },
                color = Color(0xFF92400E),
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun ExpenseItem(
    expense: Expense,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(
                        color = getCategoryColor(expense.category),
                        shape = RoundedCornerShape(16.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = expense.category.first().toString(),
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 14.dp)
            ) {
                Text(
                    text = expense.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${expense.category} • ${expense.date}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF6B7280)
                )
            }

            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "-$${String.format("%.2f", expense.amount)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFDC2626)
                )

                TextButton(
                    onClick = onDelete
                ) {
                    Text(
                        text = "Delete",
                        color = Color(0xFFDC2626),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onAddExpense: (String, Double, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Food") }

    val categories = listOf("Food", "Transport", "Bills", "Entertainment", "Shopping", "Other")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Add New Expense",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                    },
                    label = {
                        Text("Expense title")
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                    },
                    label = {
                        Text("Amount")
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Category",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.chunked(2).forEach { rowItems ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowItems.forEach { category ->
                                CategoryChip(
                                    text = category,
                                    selected = selectedCategory == category,
                                    onClick = {
                                        selectedCategory = category
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            if (rowItems.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()

                    if (title.isNotBlank() && amount != null && amount > 0) {
                        onAddExpense(
                            title.trim(),
                            amount,
                            selectedCategory
                        )
                    }
                }
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun CategoryChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor = if (selected) {
        getCategoryColor(text)
    } else {
        Color(0xFFE5E7EB)
    }

    val textColor = if (selected) {
        Color.White
    } else {
        Color(0xFF374151)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50.dp))
            .background(backgroundColor)
            .clickable {
                onClick()
            }
            .padding(
                vertical = 10.dp,
                horizontal = 12.dp
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor,
            fontWeight = FontWeight.SemiBold
        )
    }
}

fun getCategoryColor(category: String): Color {
    return when (category) {
        "Food" -> Color(0xFFF97316)
        "Transport" -> Color(0xFF10B981)
        "Bills" -> Color(0xFF6366F1)
        "Entertainment" -> Color(0xFFEC4899)
        "Shopping" -> Color(0xFF14B8A6)
        else -> Color(0xFF6B7280)
    }
}

fun currentDateText(): String {
    val formatter = SimpleDateFormat("MMM dd", Locale.getDefault())
    return formatter.format(Date())
}
